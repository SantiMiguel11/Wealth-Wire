SYNTHETIC TEST DATA - not real news
